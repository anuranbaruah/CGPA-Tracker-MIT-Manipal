# Academic Record

A Next.js app displaying B.Tech academic grade records, deployable to Vercel.

## Deploy to Vercel (3 steps)

### Option A — Vercel CLI (fastest)
```bash
npm i -g vercel
cd academic-record
vercel
```
Follow the prompts — Vercel auto-detects Next.js.

### Option B — GitHub + Vercel Dashboard
1. Push this folder to a GitHub repo
2. Go to https://vercel.com/new
3. Import the repo → click **Deploy**

That's it. No environment variables needed.

## Local Development
```bash
npm install
npm run dev
# Open http://localhost:3000
```

## Project Structure
```
academic-record/
├── lib/
│   └── data.js          # All grade data & helpers
├── pages/
│   ├── _app.js
│   └── index.js         # Main dashboard
├── styles/
│   └── globals.css
├── package.json
└── next.config.js
```

## Updating Your Grades
Edit `lib/data.js` — the `semesters` array and `ongoingSemester` object hold all the data.
