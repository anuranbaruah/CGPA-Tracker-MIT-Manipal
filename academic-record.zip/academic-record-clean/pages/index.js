import { useState } from "react";
import Head from "next/head";
import { semesters, ongoingSemester, CGPA, gradeColor, gpaColor, GRADE_POINTS } from "../lib/data";

const MAX_GPA = 10;

export default function Home() {
  const [activeSem, setActiveSem] = useState(null);

  const toggle = (id) => setActiveSem((prev) => (prev === id ? null : id));

  return (
    <>
      <Head>
        <title>Academic Record</title>
        <meta name="description" content="B.Tech Academic Grade Record" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>📊</text></svg>" />
      </Head>

      <header className="site-header">
        <div className="shell">
          <div>
            <h1 className="header-title">Academic<span>.</span>Record</h1>
            <p className="header-sub">B.Tech &nbsp;·&nbsp; Information &amp; Communication Technology</p>
          </div>
          <div className="cgpa-badge">
            <span className="cgpa-num">{CGPA.toFixed(2)}</span>
            <span className="cgpa-label">Cumulative GPA</span>
          </div>
        </div>
      </header>

      <main>
        <div className="shell">

          {/* GPA Timeline */}
          <section className="timeline-section">
            <p className="section-label">GPA — Semester Trend</p>
            <div className="gpa-chart">
              {semesters.map((sem) => {
                const pct = sem.gpa ? (sem.gpa / MAX_GPA) * 100 : 5;
                const cls = gpaColor(sem.gpa);
                const barColor =
                  cls === "kpi-high" ? "var(--high)" :
                  cls === "kpi-mid"  ? "var(--mid)"  :
                  cls === "kpi-low"  ? "var(--low)"  : "var(--s)";
                return (
                  <div
                    key={sem.id}
                    className={`gpa-bar-wrap${activeSem === sem.id ? " active" : ""}`}
                    onClick={() => toggle(sem.id)}
                    title={`${sem.label}: ${sem.gpa ?? "—"}`}
                  >
                    <div className="gpa-bar-track">
                      <div
                        className="gpa-bar-fill"
                        style={{ height: `${pct}%`, background: barColor }}
                      />
                    </div>
                    <span className="bar-sem">S{sem.roman}</span>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Semester Cards */}
          <section>
            <p className="section-label">Semester Results</p>
            <div className="sem-grid">
              {semesters.map((sem) => (
                <div
                  key={sem.id}
                  className={`sem-card${activeSem === sem.id ? " active" : ""}`}
                  onClick={() => toggle(sem.id)}
                >
                  <div className="sem-card-head">
                    <span className="sem-card-title">{sem.label}</span>
                    {sem.gpa != null ? (
                      <span className={`sem-gpa ${gpaColor(sem.gpa)}`}>
                        {sem.gpa.toFixed(2)} GPA
                      </span>
                    ) : (
                      <span className="sem-gpa" style={{ color: "var(--text3)" }}>—</span>
                    )}
                  </div>
                  <div className="sem-card-body">
                    {sem.subjects.map((s, i) => (
                      <div className="subj-row" key={i}>
                        <span className="subj-code">{s.code ?? "—"}</span>
                        <span className="subj-name" title={s.name}>{s.name}</span>
                        <span className="subj-credits">{s.credits ?? "—"}</span>
                        <span className={`grade-pill ${gradeColor(s.grade)}`}>{s.grade}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Ongoing Semester */}
          <section className="ongoing-section">
            <p className="section-label">Current Semester — Ongoing</p>
            <div className="ongoing-grid">
              <div className="ongoing-card">
                <div className="ongoing-card-head">Theory Subjects</div>
                {ongoingSemester.theory.map((s, i) => (
                  <div className="ongoing-row" key={i}>
                    <span className="ongoing-subj">{s.subject}</span>
                    <div className="ongoing-meta">
                      <div>{s.credits} cr</div>
                      {s.lab && <div style={{ color: "var(--accent2)", fontSize: 9 }}>{s.lab}</div>}
                    </div>
                    <span className="passing-pill">Pass: {s.passingMarks}</span>
                  </div>
                ))}
              </div>
              <div className="ongoing-card">
                <div className="ongoing-card-head">Lab Subjects</div>
                {ongoingSemester.lab.map((s, i) => (
                  <div className="ongoing-row" key={i}>
                    <span className="ongoing-subj">{s.subject}</span>
                    <div className="ongoing-meta">{s.credits} cr</div>
                    <span className="passing-pill">Pass: {s.passingMarks}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Grade Legend */}
          <section style={{ marginBottom: 56 }}>
            <p className="section-label">Grade Scale</p>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {Object.entries(GRADE_POINTS).map(([g, p]) => (
                <div
                  key={g}
                  className={`grade-pill ${gradeColor(g)}`}
                  style={{ width: "auto", padding: "4px 10px", fontSize: 11 }}
                >
                  {g} = {p}
                </div>
              ))}
            </div>
          </section>

        </div>
      </main>

      <footer className="site-footer">
        <p>Academic Record &nbsp;·&nbsp; Generated from V_rec.xlsx</p>
      </footer>
    </>
  );
}
